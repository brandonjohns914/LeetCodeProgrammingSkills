//: [Previous](@previous)

import Foundation

func mergeAlternately(_ word1: String, _ word2: String) -> String {
    
    
}

//: [Next](@next)
